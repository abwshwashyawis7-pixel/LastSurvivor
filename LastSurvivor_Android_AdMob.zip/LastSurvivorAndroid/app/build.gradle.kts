plugins {
    id("com.android.application")
}

android {
    namespace = "com.owis.lastsurvivor"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.owis.lastsurvivor"   // غيّره إن كان لديك معرّف مسجّل في Google Play
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        // معرّف تطبيق AdMob التجريبي الرسمي من Google. استبدله بمعرّفك الحقيقي قبل النشر فقط.
        manifestPlaceholders["admobAppId"] = "ca-app-pub-3940256099942544~3347511713"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("com.google.android.gms:play-services-ads:24.9.0")
}

// يمنع بناء نسخة "حقيقية" بمعرّفات وحدات فارغة، وينبّه عند البناء بإعلانات تجريبية.
val verifyAdsConfig = tasks.register("verifyAdsConfig") {
    val cfg = file("src/main/java/com/owis/lastsurvivor/AdsConfig.java")
    doLast {
        val text = cfg.readText()
        val testMode = !Regex("USE_TEST_ADS\\s*=\\s*false").containsMatchIn(text)
        val prodEmpty = Regex("PROD_\\w+_UNIT_ID\\s*=\\s*\"\"").containsMatchIn(text)
        if (!testMode && prodEmpty) {
            throw GradleException("AdsConfig: USE_TEST_ADS=false لكن معرّفات PROD_* فارغة.")
        }
        if (testMode) {
            logger.warn("[LastSurvivor] هذا البناء يستخدم معرّفات Google التجريبية (لا أرباح). غيّر USE_TEST_ADS إلى false للنسخة النهائية فقط.")
        }
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(verifyAdsConfig) }
