/* LastSurvivor external adapter — injected by the Android shell after the page loads.
   The game file itself is NOT modified. This script contains NO ad-network code:
   it only talks to the native layer (window.LSNative.post) and reads/writes the game's own globals. */
(function(){
'use strict';
if(window.__LSAds)return;
var NAT=window.LSNative;
if(!NAT||typeof NAT.post!=='function')return;

var MSG={
  offline:'📶 لا يوجد اتصال بالإنترنت',
  not_ready:'⏳ الإعلان غير جاهز بعد، حاول بعد لحظات',
  busy:'⏳ هناك إعلان قيد العرض',
  cooldown:'⏱ انتظر قليلًا قبل مشاهدة إعلان آخر',
  show_failed:'⚠️ تعذّر عرض الإعلان، حاول لاحقًا',
  dismissed:'لم تكتمل مشاهدة الإعلان — لم تُمنح المكافأة',
  disabled:'الإعلانات غير متاحة حاليًا'
};
var SHORT={offline:'📶 لا اتصال',not_ready:'⏳ غير جاهز',busy:'⏳ قيد العرض',cooldown:'⏱ انتظر',show_failed:'⚠️ تعذّر',dismissed:'✖ لم تكتمل',disabled:'—'};
var st={init:false,err:-1,online:true,rewardedReady:false,coins:120,offerOn:true,offerFirst:120,offerEvery:240,offerMinPlay:30,offerShow:12};
var appStart=Date.now(),lastOffer=0,lastRewardAt=0,cardEl=null,cardHeld=false,cardTimer=0;
var pendingReq=null,reqTimer=0,seq=0,note='',noteShort='',noteTimer=0;
var applied={},queue=[];
var heldByAd=false,holdTimer=0,audioWasRunning=false;
var prev={over:null,intro:null},roundStart=0,lastBreakAt=0;

function post(o){try{NAT.post(JSON.stringify(o))}catch(e){}}
function el(id){return document.getElementById(id)}
function vis(id){var e=el(id);if(!e)return false;try{return getComputedStyle(e).display!=='none'}catch(x){return false}}
function gm(){try{return (typeof g!=='undefined'&&g)?g:null}catch(e){return null}}
function say(t){try{if(typeof msg==='function')msg(t)}catch(e){}}

/* ---- feedback shown inside the pause panel (the game's #msg toast sits under the pause overlay) ---- */
function toast(t,sh){
  note=t;noteShort=sh||t;paint();say(t);
  clearTimeout(noteTimer);
  noteTimer=setTimeout(function(){note='';noteShort='';paint()},4500);
}

/* ---- the single reward entry point: a button inside the game's own pause screen ---- */
var CSS='.lsad{display:block;margin:0;padding:3px 10px;border-radius:12px;border:1px solid #c9a227;'+
  'background:linear-gradient(#5a4310,#3c2c08);color:#ffe9a8;font-size:12px;font-weight:800;white-space:nowrap}'+
  '.rs .lsad{flex:0 0 auto;display:flex;align-items:center;justify-content:center;min-width:86px}'+
  '.lsad:disabled{opacity:.6}'+
  '#lsoffer{position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);z-index:99999;min-width:260px;max-width:80vw;'+
  'padding:16px 18px;border-radius:18px;border:2px solid #c9a227;background:linear-gradient(#3c2c08,#1c1404);'+
  'color:#ffe9a8;text-align:center;direction:rtl;box-shadow:0 0 0 9999px rgba(0,0,0,.45)}'+
  '#lsoffer b{display:block;font-size:18px;margin-bottom:6px}'+
  '#lsoffer button{margin:10px 6px 0;padding:10px 16px;border-radius:12px;border:1px solid #c9a227;font-size:15px;font-weight:800}'+
  '#lsoffer .go{background:#c9a227;color:#2a1c00}#lsoffer .no{background:transparent;color:#ffe9a8}';

function paint(){
  var b=el('lsad_btn');if(!b)return;
  var txt;
  if(pendingReq)txt='⏳ ...';
  else if(noteShort)txt=noteShort;
  else if(!st.online)txt='📶';
  else if(!st.rewardedReady)txt='⏳'+(!st.init?' ·':st.err>=0?' ('+st.err+')':'');
  else txt='📺 +'+st.coins+' 🪙';
  b.textContent=txt;
  b.disabled=!!pendingReq||!st.online||!st.rewardedReady;
}

/* The reward button lives in the shop's resources row (🪵 ⛏ 🪙 [📺]) as one more small chip:
   it covers nothing and does not change the shop's layout. renderShop() rebuilds the shop, so it is re-added each time. */
function ensureBtn(){
  var s=el('shop');if(!s)return;
  var r=s.querySelector('.rs');if(!r)return;
  var b=r.querySelector('#lsad_btn');
  if(!b){
    b=document.createElement('button');
    b.id='lsad_btn';b.className='lsad';b.type='button';
    b.addEventListener('click',onRewardClick);
    r.appendChild(b);
  }
  paint();
}

function onRewardClick(ev){
  if(ev){ev.stopPropagation();if(ev.preventDefault)ev.preventDefault()}
  if(pendingReq)return;
  var gg=gm();if(!gg||!gg.p)return;
  seq++;
  var id='r'+Date.now().toString(36)+'_'+seq;
  pendingReq=id;paint();
  clearTimeout(reqTimer);
  reqTimer=setTimeout(function(){if(pendingReq===id){pendingReq=null;toast(MSG.show_failed,SHORT.show_failed)}},120000);
  post({t:'reward_request',id:id});
}

/* ---- reward delivery: exactly once per request id, never lost ---- */
function refreshPause(){try{if(vis('pause')&&typeof xPauseDraw==='function'&&gm())xPauseDraw()}catch(e){}
  try{if(vis('shop')&&typeof renderShop==='function'&&gm()&&typeof shopKind!=='undefined')renderShop(shopKind,typeof shopTab!=='undefined'?shopTab:0)}catch(e){}}

function drain(){
  if(!queue.length)return;
  var gg=gm();
  if(!gg||!gg.p||gg.over)return;            /* wait until the game is playable; the reward stays queued */
  var total=0;
  while(queue.length)total+=queue.shift();
  gg.p.coins=(gg.p.coins|0)+total;
  try{if(typeof saveGame==='function')saveGame()}catch(e){}    /* the game's own save routine, unchanged */
  refreshPause();
  toast('🎁 +'+total+' 🪙 — شكرًا لدعمك!','🎁 +'+total+' 🪙');
  post({t:'reward_applied',total:total});
}

/* ---- audio / game hold while a full-screen ad is on top ---- */
function suspendAudio(on){
  try{
    var ac=window._ac;
    if(on){if(ac&&ac.state==='running'){audioWasRunning=true;ac.suspend()}}
    else{if(audioWasRunning&&ac)ac.resume();audioWasRunning=false}
  }catch(e){}
}
function holdGame(on){
  var gg=gm();
  if(on){
    if(gg&&!gg.paused&&!gg.over){gg.paused=1;heldByAd=true}
    clearTimeout(holdTimer);
    holdTimer=setTimeout(function(){holdGame(false);suspendAudio(false)},180000);
  }else{
    clearTimeout(holdTimer);
    if(heldByAd&&gg)gg.paused=0;
    heldByAd=false;
  }
}

/* ---- natural break detection: death screen closed / back to the main menu ---- */
function tick(){
  var o=vis('over'),i=vis('intro'),now=Date.now(),kind=null;
  if(prev.intro===true&&i===false)roundStart=now;                 /* a game was started from the menu */
  if(prev.over===true&&o===false)kind='round_end';
  else if(prev.intro===false&&i===true&&roundStart)kind='menu_return';
  if(kind&&now-lastBreakAt>5000){
    lastBreakAt=now;
    post({t:'break',k:kind,played:roundStart?Math.round((now-roundStart)/1000):0});
  }
  if(i)roundStart=0;
  if(prev.intro!==i)post({t:'menu',v:!!i});                        /* main menu shown/hidden -> native banner */
  prev.over=o;prev.intro=i;
  maybeOffer(now);
  drain();
}

/* ---- timed reward offer: an opt-in card in the middle of the screen (never a surprise full-screen ad) ---- */
function closeCard(release){
  if(cardTimer){clearTimeout(cardTimer);cardTimer=0}
  if(cardEl&&cardEl.parentNode)cardEl.parentNode.removeChild(cardEl);
  cardEl=null;
  var gg=gm();
  if(release&&cardHeld&&gg)gg.paused=0;
  cardHeld=false;
  lastOffer=Date.now();
}
function offerLater(){closeCard(true)}
function offerWatch(){
  var held=cardHeld;
  closeCard(false);              /* keep the game paused: the ad takes over from here */
  if(held)heldByAd=true;
  onRewardClick();
  if(!pendingReq)holdGame(false);
}
function canOffer(now){
  var gg=gm();
  if(!st.offerOn||cardEl||pendingReq||!st.online||!st.rewardedReady)return false;
  if(!gg||!gg.p||gg.over||gg.paused||gg.shop||gg.mapo||gg.cvi)return false;
  if(vis('intro')||vis('over')||vis('pause'))return false;
  if(!roundStart||now-roundStart<st.offerMinPlay*1000)return false;
  if(now-appStart<st.offerFirst*1000)return false;
  if(now-(lastOffer||appStart)<st.offerEvery*1000)return false;
  if(lastRewardAt&&now-lastRewardAt<90000)return false;
  return true;
}
function showCard(){
  var gg=gm();if(!gg)return;
  var d=document.createElement('div');
  d.id='lsoffer';
  d.innerHTML='<b>\uD83C\uDF81 \u0647\u062F\u064A\u0629 \u0644\u0643!</b>'+
    '<div>\u0634\u0627\u0647\u062F \u0625\u0639\u0644\u0627\u0646\u064B\u0627 \u0642\u0635\u064A\u0631\u064B\u0627 \u0648\u0627\u062D\u0635\u0644 \u0639\u0644\u0649 \uD83E\uDE99 '+st.coins+'</div>'+
    '<button class="go" type="button">\uD83D\uDCFA \u0634\u0627\u0647\u062F</button>'+
    '<button class="no" type="button">\u0644\u0627\u062D\u0642\u064B\u0627</button>';
  d.querySelector('.go').addEventListener('click',function(e){e.stopPropagation();offerWatch()});
  d.querySelector('.no').addEventListener('click',function(e){e.stopPropagation();offerLater()});
  (document.body||document.documentElement).appendChild(d);
  cardEl=d;
  if(!gg.paused){gg.paused=1;cardHeld=true}
  cardTimer=setTimeout(offerLater,st.offerShow*1000);
}
function maybeOffer(now){if(canOffer(now))showCard()}

var api={
  setState:function(s){
    if(!s)return;
    if(typeof s.err==='number')st.err=s.err;
    if(typeof s.init==='boolean')st.init=s.init;
    if(typeof s.online==='boolean')st.online=s.online;
    if(typeof s.rewardedReady==='boolean')st.rewardedReady=s.rewardedReady;
    if(s.coins>0)st.coins=s.coins|0;
    if(typeof s.offerOn==='boolean')st.offerOn=s.offerOn;
    if(s.offerFirst>=0)st.offerFirst=s.offerFirst|0;
    if(s.offerEvery>0)st.offerEvery=s.offerEvery|0;
    if(s.offerMinPlay>=0)st.offerMinPlay=s.offerMinPlay|0;
    if(s.offerShow>0)st.offerShow=s.offerShow|0;
    paint();
  },
  rewardResult:function(id,res,amount){
    if(pendingReq===id){pendingReq=null;clearTimeout(reqTimer)}
    if(res==='ok'){
      lastRewardAt=Date.now();
      if(!applied[id]){applied[id]=1;queue.push(amount|0);drain()}
    }else{
      holdGame(false);
      toast(MSG[res]||MSG.show_failed,SHORT[res]||SHORT.show_failed);
    }
    paint();
  },
  adOpen:function(){holdGame(true);suspendAudio(true)},
  adClosed:function(){holdGame(false);suspendAudio(false)},
  flush:function(){try{if(typeof saveGame==='function')saveGame()}catch(e){}},
  onBack:function(){
    var gg=gm();
    if(!gg||vis('intro'))return false;                 /* main menu: let the app go to the background */
    if(vis('over'))return true;
    try{
      if(vis('pause')){resume();return true}
      if(!gg.over&&!gg.shop&&!gg.mapo){xPause();return true}
    }catch(e){}
    return true;
  }
};

window.__LSAds=api;

(function init(){
  if(!el('lsad_css')){
    var s=document.createElement('style');s.id='lsad_css';s.textContent=CSS;
    (document.head||document.documentElement).appendChild(s);
  }
  var p=el('shop');
  if(p&&window.MutationObserver)new MutationObserver(ensureBtn).observe(p,{childList:true});
  setInterval(tick,400);
  post({t:'ready'});
})();
})();
