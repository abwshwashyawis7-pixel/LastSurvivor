/* LastSurvivor external adapter — injected by the Android shell after the page loads.
   The game file itself is NOT modified. This script contains NO ad-network code:
   it only talks to the native layer (window.LSNative.post) and reads/writes the game's own globals. */
(function(){
'use strict';
if(window.__LSAds)return;
var NAT=window.LSNative;
if(!NAT||typeof NAT.post!=='function')return;

var MSG={
  offline:'📶 لا يوجد اتصال بالإنترنت',
  not_ready:'⏳ الإعلان غير جاهز بعد، حاول بعد لحظات',
  busy:'⏳ هناك إعلان قيد العرض',
  cooldown:'⏱ انتظر قليلًا قبل مشاهدة إعلان آخر',
  show_failed:'⚠️ تعذّر عرض الإعلان، حاول لاحقًا',
  dismissed:'لم تكتمل مشاهدة الإعلان — لم تُمنح المكافأة',
  disabled:'الإعلانات غير متاحة حاليًا'
};
var st={online:true,rewardedReady:false,coins:120};
var pendingReq=null,reqTimer=0,seq=0,note='',noteTimer=0;
var applied={},queue=[];
var heldByAd=false,holdTimer=0,audioWasRunning=false;
var prev={over:null,intro:null},roundStart=0,lastBreakAt=0;

function post(o){try{NAT.post(JSON.stringify(o))}catch(e){}}
function el(id){return document.getElementById(id)}
function vis(id){var e=el(id);if(!e)return false;try{return getComputedStyle(e).display!=='none'}catch(x){return false}}
function gm(){try{return (typeof g!=='undefined'&&g)?g:null}catch(e){return null}}
function say(t){try{if(typeof msg==='function')msg(t)}catch(e){}}

/* ---- feedback shown inside the pause panel (the game's #msg toast sits under the pause overlay) ---- */
function toast(t){
  note=t;paint();say(t);
  clearTimeout(noteTimer);
  noteTimer=setTimeout(function(){note='';paint()},4500);
}

/* ---- the single reward entry point: a button inside the game's own pause screen ---- */
var CSS='.lsad{display:block;width:100%;margin-top:8px;padding:10px;border-radius:14px;border:1px solid #c9a227;'+
  'background:linear-gradient(#5a4310,#3c2c08);color:#ffe9a8;font-size:15px;font-weight:800}'+
  '.lsad:disabled{opacity:.6}';

function paint(){
  var b=el('lsad_btn');if(!b)return;
  var txt;
  if(pendingReq)txt='⏳ جارٍ عرض الإعلان...';
  else if(note)txt=note;
  else if(!st.online)txt='📶 لا يوجد اتصال بالإنترنت';
  else if(!st.rewardedReady)txt='⏳ يجري تجهيز الإعلان...';
  else txt='📺 شاهد إعلانًا واحصل على 🪙 '+st.coins;
  b.textContent=txt;
  b.disabled=!!pendingReq||!st.online||!st.rewardedReady;
}

function ensureBtn(){
  var p=el('pause');if(!p)return;
  var z=p.querySelector('.pz');if(!z)return;
  var b=z.querySelector('#lsad_btn');
  if(!b){
    b=document.createElement('button');
    b.id='lsad_btn';b.className='lsad';b.type='button';
    b.addEventListener('click',onRewardClick);
    var s=z.querySelector('.pz-s');
    if(s&&s.nextSibling)z.insertBefore(b,s.nextSibling);else z.appendChild(b);
  }
  paint();
}

function onRewardClick(ev){
  if(ev){ev.stopPropagation();if(ev.preventDefault)ev.preventDefault()}
  if(pendingReq)return;
  var gg=gm();if(!gg||!gg.p)return;
  seq++;
  var id='r'+Date.now().toString(36)+'_'+seq;
  pendingReq=id;paint();
  clearTimeout(reqTimer);
  reqTimer=setTimeout(function(){if(pendingReq===id){pendingReq=null;toast(MSG.show_failed)}},120000);
  post({t:'reward_request',id:id});
}

/* ---- reward delivery: exactly once per request id, never lost ---- */
function refreshPause(){try{if(vis('pause')&&typeof xPauseDraw==='function'&&gm())xPauseDraw()}catch(e){}}

function drain(){
  if(!queue.length)return;
  var gg=gm();
  if(!gg||!gg.p||gg.over)return;            /* wait until the game is playable; the reward stays queued */
  var total=0;
  while(queue.length)total+=queue.shift();
  gg.p.coins=(gg.p.coins|0)+total;
  try{if(typeof saveGame==='function')saveGame()}catch(e){}    /* the game's own save routine, unchanged */
  refreshPause();
  toast('🎁 +'+total+' 🪙 — شكرًا لدعمك!');
  post({t:'reward_applied',total:total});
}

/* ---- audio / game hold while a full-screen ad is on top ---- */
function suspendAudio(on){
  try{
    var ac=window._ac;
    if(on){if(ac&&ac.state==='running'){audioWasRunning=true;ac.suspend()}}
    else{if(audioWasRunning&&ac)ac.resume();audioWasRunning=false}
  }catch(e){}
}
function holdGame(on){
  var gg=gm();
  if(on){
    if(gg&&!gg.paused&&!gg.over){gg.paused=1;heldByAd=true}
    clearTimeout(holdTimer);
    holdTimer=setTimeout(function(){holdGame(false);suspendAudio(false)},180000);
  }else{
    clearTimeout(holdTimer);
    if(heldByAd&&gg)gg.paused=0;
    heldByAd=false;
  }
}

/* ---- natural break detection: death screen closed / back to the main menu ---- */
function tick(){
  var o=vis('over'),i=vis('intro'),now=Date.now(),kind=null;
  if(prev.intro===true&&i===false)roundStart=now;                 /* a game was started from the menu */
  if(prev.over===true&&o===false)kind='round_end';
  else if(prev.intro===false&&i===true&&roundStart)kind='menu_return';
  if(kind&&now-lastBreakAt>5000){
    lastBreakAt=now;
    post({t:'break',k:kind,played:roundStart?Math.round((now-roundStart)/1000):0});
  }
  if(i)roundStart=0;
  prev.over=o;prev.intro=i;
  drain();
}

var api={
  setState:function(s){
    if(!s)return;
    if(typeof s.online==='boolean')st.online=s.online;
    if(typeof s.rewardedReady==='boolean')st.rewardedReady=s.rewardedReady;
    if(s.coins>0)st.coins=s.coins|0;
    paint();
  },
  rewardResult:function(id,res,amount){
    if(pendingReq===id){pendingReq=null;clearTimeout(reqTimer)}
    if(res==='ok'){
      if(!applied[id]){applied[id]=1;queue.push(amount|0);drain()}
    }else{
      toast(MSG[res]||MSG.show_failed);
    }
    paint();
  },
  adOpen:function(){holdGame(true);suspendAudio(true)},
  adClosed:function(){holdGame(false);suspendAudio(false)},
  flush:function(){try{if(typeof saveGame==='function')saveGame()}catch(e){}},
  onBack:function(){
    var gg=gm();
    if(!gg||vis('intro'))return false;                 /* main menu: let the app go to the background */
    if(vis('over'))return true;
    try{
      if(vis('pause')){resume();return true}
      if(!gg.over&&!gg.shop&&!gg.mapo){xPause();return true}
    }catch(e){}
    return true;
  }
};

window.__LSAds=api;

(function init(){
  if(!el('lsad_css')){
    var s=document.createElement('style');s.id='lsad_css';s.textContent=CSS;
    (document.head||document.documentElement).appendChild(s);
  }
  var p=el('pause');
  if(p&&window.MutationObserver)new MutationObserver(ensureBtn).observe(p,{childList:true});
  setInterval(tick,400);
  post({t:'ready'});
})();
})();
