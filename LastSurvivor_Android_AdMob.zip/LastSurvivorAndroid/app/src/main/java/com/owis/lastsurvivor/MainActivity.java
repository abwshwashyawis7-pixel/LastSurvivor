package com.owis.lastsurvivor;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/**
 * Shows the unmodified HTML game in a full-screen WebView and connects it to {@link AdController}.
 * The game never talks to AdMob: an external adapter script (assets/ls_ads_adapter.js, injected after the page
 * loads) posts small JSON messages through window.LSNative.post(...):
 *   {t:"ready"} {t:"reward_request",id} {t:"break",k,played} {t:"reward_applied",total}
 * and receives results through window.__LSAds.* calls.
 */
public final class MainActivity extends Activity implements AdController.Listener {
    private static final String TAG = "LastSurvivor";
    private static final String GAME_URL = "file:///android_asset/last_survivor_v10.html";

    private WebView web;
    private FrameLayout root;
    private AdController ads;
    private String adapterJs = "";

    // ---------------------------------------------------------------- lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        adapterJs = readAsset("ls_ads_adapter.js");

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        setContentView(root);
        createWebView();
        web.loadUrl(GAME_URL);

        ads = new AdController(this, this);
        ads.start();
        hideSystemUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) {
            web.onResume();
            web.resumeTimers();
        }
        hideSystemUi();
    }

    @Override
    protected void onPause() {
        if (web != null) {
            web.evaluateJavascript("window.__LSAds&&window.__LSAds.flush()", null); // game saves via its own routine
            web.onPause();
            web.pauseTimers();
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (ads != null) ads.stop();
        destroyWebView();
        super.onDestroy();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    /** Back key: the page decides (open/close its pause screen); from the main menu the app goes to the background. */
    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript(
                "(window.__LSAds&&window.__LSAds.onBack&&window.__LSAds.onBack())?'1':'0'",
                value -> {
                    if (value != null && value.contains("1")) return;
                    moveTaskToBack(true);
                });
    }

    // ---------------------------------------------------------------- WebView

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void createWebView() {
        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);
        web.setLongClickable(false);
        web.setHapticFeedbackEnabled(false);
        web.setOnLongClickListener(v -> true);
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);                 // localStorage = the game's save system
        s.setAllowFileAccess(true);                   // file:///android_asset/...
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setAllowContentAccess(false);
        s.setBlockNetworkLoads(true);                 // the game is fully offline
        s.setMediaPlaybackRequiresUserGesture(false); // game audio works as in a normal browser tab
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(false);

        web.addJavascriptInterface(new JsApi(), "LSNative");

        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                if (!adapterJs.isEmpty()) view.evaluateJavascript(adapterJs, null);
            }

            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !isLocalGameUrl(request.getUrl());
            }

            @SuppressWarnings("deprecation")
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return !isLocalGameUrl(Uri.parse(url));
            }

            @TargetApi(Build.VERSION_CODES.O)
            @Override public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                Log.e(TAG, "WebView render process gone; recreating");
                destroyWebView();
                createWebView();
                web.loadUrl(GAME_URL);
                return true;
            }
        });

        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        web.requestFocus();
    }

    private void destroyWebView() {
        if (web == null) return;
        try {
            root.removeView(web);
            web.removeJavascriptInterface("LSNative");
            web.destroy();
        } catch (RuntimeException e) {
            Log.w(TAG, "destroy failed: " + e);
        }
        web = null;
    }

    private static boolean isLocalGameUrl(Uri uri) {
        if (uri == null) return false;
        String path = uri.getPath();
        return "file".equals(uri.getScheme()) && path != null && path.startsWith("/android_asset/");
    }

    private void evaluate(final String js) {
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    // ---------------------------------------------------------------- page -> native

    private final class JsApi {
        @JavascriptInterface
        public void post(final String json) {
            if (json == null || json.length() > 4000) return;
            runOnUiThread(() -> handleMessage(json));
        }
    }

    private void handleMessage(String json) {
        String type;
        JSONObject m;
        try {
            m = new JSONObject(json);
            type = m.optString("t", "");
        } catch (Exception e) {
            return;
        }
        switch (type) {
            case "ready":
                pushState();
                break;
            case "reward_request":
                handleRewardRequest(m.optString("id", ""));
                break;
            case "break":
                ads.tryShowInterstitial(m.optString("k", ""), m.optInt("played", 0));
                break;
            case "reward_applied":
                Log.i(TAG, "Reward applied in game: +" + m.optInt("total", 0));
                break;
            default:
                break;
        }
    }

    private void handleRewardRequest(String rawId) {
        final String id = sanitize(rawId);
        if (id == null) return;
        ads.showRewarded(id, result -> {
            int amount = result == AdController.RewardResult.GRANTED ? AdsConfig.REWARD_COINS : 0;
            evaluate("window.__LSAds&&window.__LSAds.rewardResult('" + id + "','" + code(result) + "'," + amount + ")");
        });
    }

    /** Request ids come from the page: accept only [A-Za-z0-9_], max 48 chars (prevents JS injection). */
    private static String sanitize(String id) {
        if (id == null || id.isEmpty() || id.length() > 48) return null;
        for (int i = 0; i < id.length(); i++) {
            char c = id.charAt(i);
            boolean ok = (c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_';
            if (!ok) return null;
        }
        return id;
    }

    private static String code(AdController.RewardResult r) {
        switch (r) {
            case GRANTED: return "ok";
            case DISMISSED: return "dismissed";
            case NOT_READY: return "not_ready";
            case OFFLINE: return "offline";
            case BUSY: return "busy";
            case COOLDOWN: return "cooldown";
            case SHOW_FAILED: return "show_failed";
            default: return "disabled";
        }
    }

    // ---------------------------------------------------------------- native -> page (AdController.Listener)

    private static String b(boolean v) { return v ? "true" : "false"; }

    private void pushState() {
        evaluate("window.__LSAds&&window.__LSAds.setState({online:" + b(ads.isOnline())
                + ",rewardedReady:" + b(ads.isRewardedReady())
                + ",coins:" + AdsConfig.REWARD_COINS
                + ",offerOn:" + b(AdsConfig.OFFER_ENABLED)
                + ",offerFirst:" + AdsConfig.OFFER_FIRST_AFTER_SECONDS
                + ",offerEvery:" + AdsConfig.OFFER_EVERY_SECONDS
                + ",offerMinPlay:" + AdsConfig.OFFER_MIN_PLAY_SECONDS
                + ",offerShow:" + AdsConfig.OFFER_VISIBLE_SECONDS + "})");
    }

    @Override public void onStateChanged() { pushState(); }

    @Override public void onFullscreenOpened() { evaluate("window.__LSAds&&window.__LSAds.adOpen()"); }

    @Override public void onFullscreenClosed() { evaluate("window.__LSAds&&window.__LSAds.adClosed()"); }

    // ---------------------------------------------------------------- helpers

    @SuppressWarnings("deprecation")
    private void hideSystemUi() {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                WindowInsetsController c = getWindow().getInsetsController();
                if (c != null) {
                    c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                    c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                }
            } else {
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            }
        } catch (RuntimeException e) {
            Log.w(TAG, "hideSystemUi failed: " + e);
        }
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        } catch (Exception e) {
            Log.e(TAG, "Missing asset " + name + " - the game runs without ad buttons.");
            return "";
        }
    }
}
