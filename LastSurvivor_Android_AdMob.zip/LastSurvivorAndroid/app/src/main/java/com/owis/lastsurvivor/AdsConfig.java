package com.owis.lastsurvivor;

/**
 * Single place for every ad setting. Ships with Google's OFFICIAL TEST ids only;
 * real ids are intentionally absent (see README_AR.md, "قبل النشر").
 */
final class AdsConfig {
    private AdsConfig() {}

    // Switch to false ONLY for the release build, after filling the PROD_* ids below.
    static final boolean USE_TEST_ADS = true;

    // Google's public sample ad units (always serve test ads).
    // "Rewarded" slot = REWARDED INTERSTITIAL ad type (the type created in AdMob for this app).
    static final String TEST_REWARDED_UNIT_ID = "ca-app-pub-3940256099942544/5354046379";
    static final String TEST_INTERSTITIAL_UNIT_ID = "ca-app-pub-3940256099942544/1033173712";

    // Real ad units (AdMob publisher 8906709954295849).
    static final String PROD_REWARDED_UNIT_ID = "ca-app-pub-8906709954295849/7358746612"; // Rewarded Interstitial
    // Optional: leave empty to disable between-round interstitials. Fill with an AdMob *Interstitial* unit id to enable.
    static final String PROD_INTERSTITIAL_UNIT_ID = "";

    static String rewardedUnitId() { return USE_TEST_ADS ? TEST_REWARDED_UNIT_ID : PROD_REWARDED_UNIT_ID; }
    static String interstitialUnitId() { return USE_TEST_ADS ? TEST_INTERSTITIAL_UNIT_ID : PROD_INTERSTITIAL_UNIT_ID; }
    static boolean adsEnabled() { return !rewardedUnitId().isEmpty(); }
    static boolean interstitialEnabled() { return !interstitialUnitId().isEmpty(); }

    // ---- Reward ----
    static final int REWARD_COINS = 120;               // coins granted after a COMPLETED rewarded ad
    static final float REWARD_COOLDOWN_SECONDS = 20f;  // blocks rapid re-requests

    // ---- Timed reward offer (card in the middle of the screen, opt-in: "watch an ad, get coins") ----
    static final boolean OFFER_ENABLED = true;
    static final int OFFER_FIRST_AFTER_SECONDS = 120;   // not in the first 2 minutes after launch
    static final int OFFER_EVERY_SECONDS = 240;         // every 4 minutes (change this number)
    static final int OFFER_MIN_PLAY_SECONDS = 30;       // only after the current round lasted 30s+
    static final int OFFER_VISIBLE_SECONDS = 12;        // card disappears by itself if ignored

    // ---- Interstitial pacing (natural breaks only: closing the death screen / returning to the main menu) ----
    static final float FIRST_ALLOWED_AFTER_SECONDS = 120f; // never in the first 2 minutes after launch
    static final float MIN_GAP_SECONDS = 180f;             // >= 3 minutes between interstitials
    static final int EVERY_NTH_BREAK = 2;                  // every 2nd eligible break
    static final int MIN_PLAY_SECONDS = 60;                // ignore breaks after rounds shorter than a minute
    static final float GRACE_AFTER_REWARD_SECONDS = 90f;   // none right after the player chose to watch a reward ad
    static final int MAX_PER_SESSION = 6;
}
