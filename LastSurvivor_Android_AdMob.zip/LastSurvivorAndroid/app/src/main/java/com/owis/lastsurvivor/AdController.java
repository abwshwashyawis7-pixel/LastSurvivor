package com.owis.lastsurvivor;

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

/**
 * All AdMob logic lives here (native Java only — nothing ad-related is in the HTML/JS).
 * Rewarded: granted ONLY after the SDK confirms the reward AND the ad closed, exactly once per request id.
 * Interstitial: only at natural breaks, paced by {@link InterstitialPolicy}.
 * Load failures / offline: silent exponential back-off retry; the game is never blocked.
 * Everything runs on the main thread.
 */
final class AdController {
    private static final String TAG = "AdController";
    private static final float AD_MAX_AGE_SECONDS = 50f * 60f; // loaded ads expire after ~1h

    enum RewardResult { GRANTED, DISMISSED, NOT_READY, OFFLINE, BUSY, COOLDOWN, SHOW_FAILED, DISABLED }

    interface Listener {
        void onStateChanged();
        void onFullscreenOpened();
        void onFullscreenClosed();
    }

    interface RewardCallback {
        void onResult(RewardResult result);
    }

    private final Activity activity;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final RewardLedger ledger = new RewardLedger();
    private final InterstitialPolicy policy = InterstitialPolicy.fromConfig();
    private final long startMs = SystemClock.elapsedRealtime();

    private RewardedAd rewarded;
    private InterstitialAd interstitial;
    private boolean rewardedLoading, interstitialLoading, showing, initStarted, initialized, stopped;
    private int rewardedFails, interstitialFails;
    private float rewardedRetryAt, interstitialRetryAt, rewardedLoadedAt, interstitialLoadedAt, initRetryAt;
    private float lastRewardAt = Float.NEGATIVE_INFINITY;
    private boolean online = true, pubReady, pubOnline = true;

    AdController(Activity activity, Listener listener) {
        this.activity = activity;
        this.listener = listener;
    }

    // ------------------------------------------------------------------ lifecycle

    void start() {
        stopped = false;
        beginInit();
        main.postDelayed(tick, 2000);
    }

    void stop() {
        stopped = true;
        main.removeCallbacksAndMessages(null);
        rewarded = null;
        interstitial = null;
    }

    boolean isOnline() { return online; }

    boolean isRewardedReady() {
        return AdsConfig.adsEnabled() && initialized && !showing && rewarded != null;
    }

    private float now() { return (SystemClock.elapsedRealtime() - startMs) / 1000f; }

    private boolean checkOnline() {
        try {
            ConnectivityManager cm = (ConnectivityManager) activity.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return true;
            Network n = cm.getActiveNetwork();
            if (n == null) return false;
            NetworkCapabilities c = cm.getNetworkCapabilities(n);
            return c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        } catch (RuntimeException e) {
            return true; // unknown -> let the SDK decide
        }
    }

    // ------------------------------------------------------------------ init

    private void beginInit() {
        if (initStarted || initialized) return;
        if (!AdsConfig.adsEnabled()) {
            Log.w(TAG, "No ad unit ids configured - ads disabled (game still works).");
            return;
        }
        initStarted = true;
        final Context app = activity.getApplicationContext();
        // Initialize off the main thread (Google's recommendation); continue on the main thread.
        new Thread(new Runnable() {
            @Override public void run() {
                MobileAds.initialize(app, status -> main.post(new Runnable() {
                    @Override public void run() {
                        if (stopped) return;
                        initialized = true;
                        Log.i(TAG, "Initialized (test ads: " + AdsConfig.USE_TEST_ADS + ")");
                        loadRewarded();
                        loadInterstitial();
                        notifyState(true);
                    }
                }));
            }
        }, "ads-init").start();
    }

    // ------------------------------------------------------------------ maintenance loop (every 2 s)

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (stopped) return;
            onTick();
            main.postDelayed(this, 2000);
        }
    };

    private void onTick() {
        float t = now();
        online = checkOnline();

        if (!initialized) {
            notifyState(false);
            return;
        }
        if (!showing) {
            if (rewarded != null && t - rewardedLoadedAt > AD_MAX_AGE_SECONDS) rewarded = null;
            if (interstitial != null && t - interstitialLoadedAt > AD_MAX_AGE_SECONDS) interstitial = null;
        }
        if (online) {
            if (rewarded == null && !rewardedLoading && t >= rewardedRetryAt) loadRewarded();
            if (interstitial == null && !interstitialLoading && t >= interstitialRetryAt) loadInterstitial();
        }
        notifyState(false);
    }

    private void notifyState(boolean force) {
        boolean ready = isRewardedReady();
        if (!force && ready == pubReady && online == pubOnline) return;
        pubReady = ready;
        pubOnline = online;
        listener.onStateChanged();
    }

    private static float backoff(int fails) {
        int exp = Math.max(0, Math.min(fails - 1, 4));
        return Math.min(60f, 5f * (float) Math.pow(2, exp));
    }

    // ------------------------------------------------------------------ loading

    private void loadRewarded() {
        if (!initialized || rewardedLoading || rewarded != null || stopped) return;
        rewardedLoading = true;
        RewardedAd.load(activity, AdsConfig.rewardedUnitId(), new AdRequest.Builder().build(),
                new RewardedAdLoadCallback() {
                    @Override public void onAdLoaded(RewardedAd ad) {
                        rewardedLoading = false;
                        rewardedFails = 0;
                        rewarded = ad;
                        rewardedLoadedAt = now();
                        notifyState(false);
                    }

                    @Override public void onAdFailedToLoad(LoadAdError error) {
                        rewardedLoading = false;
                        rewardedFails++;
                        rewardedRetryAt = now() + backoff(rewardedFails);
                        Log.w(TAG, "Rewarded load failed (#" + rewardedFails + "): " + error);
                        notifyState(false);
                    }
                });
    }

    private void loadInterstitial() {
        if (!initialized || interstitialLoading || interstitial != null || stopped) return;
        interstitialLoading = true;
        InterstitialAd.load(activity, AdsConfig.interstitialUnitId(), new AdRequest.Builder().build(),
                new InterstitialAdLoadCallback() {
                    @Override public void onAdLoaded(InterstitialAd ad) {
                        interstitialLoading = false;
                        interstitialFails = 0;
                        interstitial = ad;
                        interstitialLoadedAt = now();
                    }

                    @Override public void onAdFailedToLoad(LoadAdError error) {
                        interstitialLoading = false;
                        interstitialFails++;
                        interstitialRetryAt = now() + backoff(interstitialFails);
                        Log.w(TAG, "Interstitial load failed (#" + interstitialFails + "): " + error);
                    }
                });
    }

    // ------------------------------------------------------------------ rewarded

    /** Always calls {@code done} exactly once, on the main thread. */
    void showRewarded(final String requestId, final RewardCallback done) {
        if (!AdsConfig.adsEnabled()) { done.onResult(RewardResult.DISABLED); return; }
        if (showing) { done.onResult(RewardResult.BUSY); return; }
        if (now() - lastRewardAt < AdsConfig.REWARD_COOLDOWN_SECONDS) { done.onResult(RewardResult.COOLDOWN); return; }
        if (!initialized || rewarded == null) {
            done.onResult(checkOnline() ? RewardResult.NOT_READY : RewardResult.OFFLINE);
            loadRewarded();
            return;
        }

        final RewardedAd ad = rewarded;
        rewarded = null;
        showing = true;
        final boolean[] earned = {false};
        final boolean[] finished = {false};
        notifyState(false);

        ad.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override public void onAdDismissedFullScreenContent() {
                if (finished[0]) return;
                finished[0] = true;
                // The reward callback can trail the "dismissed" event by a moment: wait briefly so a legitimately
                // completed ad is never lost. A reward is still granted ONLY if the SDK reported it.
                main.postDelayed(new Runnable() {
                    @Override public void run() { finishRewarded(requestId, earned[0], done); }
                }, 300);
            }

            @Override public void onAdFailedToShowFullScreenContent(AdError error) {
                if (finished[0]) return;
                finished[0] = true;
                Log.w(TAG, "Rewarded failed to open: " + error);
                showing = false;
                listener.onFullscreenClosed();
                done.onResult(RewardResult.SHOW_FAILED);
                loadRewarded();
                notifyState(false);
            }
        });

        listener.onFullscreenOpened();
        try {
            ad.show(activity, rewardItem -> earned[0] = true);
        } catch (RuntimeException ex) {
            Log.w(TAG, "Rewarded show threw: " + ex.getMessage());
            if (!finished[0]) {
                finished[0] = true;
                showing = false;
                listener.onFullscreenClosed();
                done.onResult(RewardResult.SHOW_FAILED);
                loadRewarded();
                notifyState(false);
            }
        }
    }

    private void finishRewarded(String requestId, boolean earned, RewardCallback done) {
        showing = false;
        listener.onFullscreenClosed();
        if (earned && ledger.tryGrant(requestId)) {
            lastRewardAt = now();
            policy.markReward(now());
            done.onResult(RewardResult.GRANTED);
        } else {
            done.onResult(RewardResult.DISMISSED);
        }
        loadRewarded();
        notifyState(false);
    }

    // ------------------------------------------------------------------ interstitial

    /** Called at natural breaks only. Returns true if an ad was actually shown. */
    boolean tryShowInterstitial(String breakKind, int playedSeconds) {
        if (!AdsConfig.adsEnabled() || !initialized || showing || interstitial == null) return false;
        float t = now();
        if (!policy.shouldShow(t, playedSeconds)) return false;

        final InterstitialAd ad = interstitial;
        interstitial = null;
        showing = true;
        policy.markShown(t);
        final boolean[] finished = {false};

        final Runnable close = new Runnable() {
            @Override public void run() {
                if (finished[0]) return;
                finished[0] = true;
                showing = false;
                listener.onFullscreenClosed();
                loadInterstitial();
            }
        };
        ad.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override public void onAdDismissedFullScreenContent() { close.run(); }

            @Override public void onAdFailedToShowFullScreenContent(AdError error) {
                Log.w(TAG, "Interstitial failed to open: " + error);
                close.run();
            }
        });

        listener.onFullscreenOpened();
        try {
            ad.show(activity);
        } catch (RuntimeException ex) {
            Log.w(TAG, "Interstitial show threw: " + ex.getMessage());
            close.run();
            return false;
        }
        return true;
    }
}
