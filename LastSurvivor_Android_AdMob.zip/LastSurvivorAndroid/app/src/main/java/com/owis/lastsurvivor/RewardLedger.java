package com.owis.lastsurvivor;

import java.util.HashSet;
import java.util.Set;

/** Guarantees a reward request id can be granted at most once. */
final class RewardLedger {
    private final Set<String> granted = new HashSet<>();

    boolean tryGrant(String requestId) {
        return requestId != null && !requestId.isEmpty() && granted.add(requestId);
    }
}
