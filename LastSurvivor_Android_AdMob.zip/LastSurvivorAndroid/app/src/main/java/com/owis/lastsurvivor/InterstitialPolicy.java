package com.owis.lastsurvivor;

/** Pure pacing logic deciding whether a natural break may show an interstitial. */
final class InterstitialPolicy {
    private final float firstAllowedAt, minGap, graceAfterReward;
    private final int everyNth, minPlaySeconds, maxPerSession;
    private float lastShown = Float.NEGATIVE_INFINITY, lastReward = Float.NEGATIVE_INFINITY;
    private int eligibleBreaks, shown;

    InterstitialPolicy(float firstAllowedAt, float minGap, int everyNth, int minPlaySeconds,
                       float graceAfterReward, int maxPerSession) {
        this.firstAllowedAt = firstAllowedAt;
        this.minGap = minGap;
        this.everyNth = everyNth < 1 ? 1 : everyNth;
        this.minPlaySeconds = minPlaySeconds;
        this.graceAfterReward = graceAfterReward;
        this.maxPerSession = maxPerSession;
    }

    static InterstitialPolicy fromConfig() {
        return new InterstitialPolicy(AdsConfig.FIRST_ALLOWED_AFTER_SECONDS, AdsConfig.MIN_GAP_SECONDS,
                AdsConfig.EVERY_NTH_BREAK, AdsConfig.MIN_PLAY_SECONDS,
                AdsConfig.GRACE_AFTER_REWARD_SECONDS, AdsConfig.MAX_PER_SESSION);
    }

    /** @param now seconds since app start */
    boolean shouldShow(float now, int playedSeconds) {
        if (shown >= maxPerSession) return false;
        if (now < firstAllowedAt) return false;
        if (playedSeconds < minPlaySeconds) return false;
        if (now - lastShown < minGap) return false;
        if (now - lastReward < graceAfterReward) return false;
        eligibleBreaks++;
        return eligibleBreaks % everyNth == 0;
    }

    void markShown(float now) { lastShown = now; shown++; }
    void markReward(float now) { lastReward = now; }
}
