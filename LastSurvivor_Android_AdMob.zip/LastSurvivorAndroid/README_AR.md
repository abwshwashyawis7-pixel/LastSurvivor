# آخر ناجي — نسخة أندرويد أصلية (بدون Unity) + إعلانات AdMob التجريبية

لعبة `last_survivor_v10.html` تعمل كما هي داخل WebView، وكل منطق الإعلانات في Java داخل التطبيق.
ملف اللعبة **غير معدَّل** (SHA-256: `10891f24…6946ef`). لا يوجد أي كود إعلانات داخل HTML أو JavaScript.
يُبنى الـAPK على GitHub Actions، فلا تحتاج Android Studio ولا حاسوبًا.

## البنية

| المسار | الوظيفة |
|---|---|
| `app/src/main/assets/last_survivor_v10.html` | اللعبة الأصلية |
| `app/src/main/assets/ls_ads_adapter.js` | سكربت ربط خارجي يُحقن بعد تحميل الصفحة: يضيف زر المكافأة في شاشة الإيقاف المؤقت ويكتشف نهاية الجولة (لا يحتوي كود AdMob) |
| `.../MainActivity.java` | WebView بملء الشاشة (أفقي) + جسر الرسائل مع الإعلانات |
| `.../AdController.java` | كل منطق AdMob: تهيئة، تحميل، إعادة محاولة، Rewarded، Interstitial |
| `.../InterstitialPolicy.java` | قواعد ظهور الإعلان البيني بدون إزعاج |
| `.../RewardLedger.java` | منع تكرار المكافأة لنفس الطلب |
| `.../AdsConfig.java` | **كل الإعدادات**: المعرّفات التجريبية، قيمة المكافأة (120 🪙)، فترات الإعلان البيني |
| `.github/workflows/build-apk.yml` | بناء APK تلقائيًا |

## البناء من الهاتف (Termux + GitHub Actions)

```bash
unzip LastSurvivor_Android_AdMob.zip && cd LastSurvivorAndroid
git init -b main && git add . && git commit -m "Last Survivor + AdMob test ads"
git remote add origin https://github.com/owis31/LastSurvivor.git   # أنشئ المستودع فارغًا أولًا
git push -u origin main
```

بعد الدفع: تبويب **Actions** ← **Build APK** ← انتظر ← نزّل الملف من **Artifacts** (`LastSurvivor-debug-apk`) ثم ثبّته.
إن فشل البناء انسخ لي آخر 30 سطرًا من سجل الخطأ وأصلحه.

## كيف تختبر الإعلانات

1. شغّل اللعبة وابدأ اللعب ← اضغط ☰ (إيقاف مؤقت) ← زر **📺 شاهد إعلانًا واحصل على 🪙 120**.
   - شاهده للنهاية ← تزيد العملات 120 مرة واحدة فقط.
   - أغلقه قبل الاكتمال ← لا مكافأة ورسالة توضّح ذلك.
   - وضع الطيران ← الزر يتحول إلى «لا يوجد اتصال بالإنترنت».
2. **الإعلان البيني** يظهر عند إغلاق شاشة الموت (إحياء/القائمة) أو العودة للقائمة الرئيسية، بشرط: دقيقتان على فتح التطبيق، جولة ≥ 60 ثانية، كل فاصل ثانٍ مؤهَّل، وفاصل ≥ 3 دقائق.
   للاختبار السريع غيّر القيم في `AdsConfig.java` (`FIRST_ALLOWED_AFTER_SECONDS=0`, `MIN_GAP_SECONDS=0`, `EVERY_NTH_BREAK=1`, `MIN_PLAY_SECONDS=0`) ثم أعدها.
3. لا توجد لافتات (Banner) إطلاقًا، فلا شيء يغطي أزرار التحكم. الإعلانات التجريبية تحمل علامة **Test Ad**.

## قبل النشر (لم يُنفَّذ عمدًا)

- في AdMob: أنشئ التطبيق ووحدتين إعلانيتين. ضع معرّف التطبيق في `app/build.gradle.kts` (`admobAppId`) والوحدتين في `PROD_*` داخل `AdsConfig.java`، ثم `USE_TEST_ADS = false` (البناء يفشل إن بقيت المعرّفات فارغة).
- فعّل نموذج الموافقة UMP لمستخدمي أوروبا/بريطانيا.
- غيّر `applicationId` إن كان لديك معرّف مسجّل في Google Play، وأنشئ Keystore للتوقيع وابنِ AAB (`bundleRelease`).
- أضف `app-ads.txt` على موقعك وأكمل «أمان البيانات» في Play Console.
